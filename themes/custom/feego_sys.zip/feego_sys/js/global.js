/**
 * @file
 * Global utilities.
 *
 */
(function (Drupal) {

  'use strict';

  Drupal.behaviors.feego_sys = {
    attach: function (context, settings) {

    }
  };

})(Drupal);
